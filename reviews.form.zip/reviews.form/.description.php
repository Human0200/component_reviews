<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arComponentDescription = [
    "NAME" => "Форма отзыва",
    "DESCRIPTION" => "Форма добавления отзыва о товаре",
    "PATH" => [
        "ID" => "leadspace",
        "NAME" => "Кастомные компоненты отзывов"
    ],
];
?>